<?php

phpinfo();

?>

