
<?php include "header.php";?>

<h1>Selamat Datang di Aplikasi Akademik </h1>

<?php include "footer.php";?>