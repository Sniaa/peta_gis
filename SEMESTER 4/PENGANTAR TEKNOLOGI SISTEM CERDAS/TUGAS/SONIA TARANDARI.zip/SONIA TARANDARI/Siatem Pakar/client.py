import requests

url = 'http://127.0.0.1:5000/get_info'

query = input("Ask about cholesterol: ")

response = requests.post(url, json={'query': query})
data = response.json()

print("Answer:", data['answer'])
print("Contact Expert:")
print("Name:", data['contact']['name'])
print("Email:", data['contact']['email'])
print("Phone:", data['contact']['phone'])
