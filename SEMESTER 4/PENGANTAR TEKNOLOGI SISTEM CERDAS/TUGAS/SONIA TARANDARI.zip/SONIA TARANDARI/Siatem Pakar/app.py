from flask import Flask, request, render_template, jsonify

app = Flask(__name__)

# Informasi kolesterol
cholesterol_info = {
    'total_cholesterol': 'Kolesterol total adalah jumlah dari kandungan kolesterol dalam darah Anda.',
    'gejala': '1.Nyeri di bagian tengkuk dada atau persendian 3.Mudah merasa lelah dan nyeri di kaki 4.Otot tubuh mudah lelah 5.Kaki dan tangan mudah kesemutan 6.Rasa sakit pada rahang 7.Xanthoma 8.Disfungsi ereksi.',
    'hdl': 'High-density lipoprotein (HDL) dikenal sebagai kolesterol baik.',
    'ldl': 'Low-density lipoprotein (LDL) dikenal sebagai kolesterol jahat.',
    'triglycerides': 'Triglycerides adalah jenis lemak yang paling umum di tubuh Anda.',
    'pengertian': 'Kolesterol adalah lemak yang penting untuk tubuh, tetapi jika terlalu tinggi, bisa menyebabkan berbagai komplikasi.'
}
 
contact_info = {
    'name': 'Dr. Sonia Trdr,S.kes',
    'email': 'sniatrdr@gmail.com',
    'phone': '+1-234-567-890'
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_info', methods=['POST'])
def get_info():
    query = request.form.get('query', '').lower()

    response = {}
    if 'total' in query:
        response['answer'] = cholesterol_info['total_cholesterol']
    elif 'hdl' in query:
        response['answer'] = cholesterol_info['hdl']
    elif 'apa saja gejala kolestrol' in query:
        response['answer'] = cholesterol_info['gejala']
    elif 'ldl' in query:
        response['answer'] = cholesterol_info['ldl']
    elif 'triglycerides' in query:
        response['answer'] = cholesterol_info['triglycerides']
    elif 'apa itu kolestrol' in query:
        response['answer'] = cholesterol_info['pengertian']
    else:
        response['answer'] = 'Saya dapat memberikan informasi tentang kolesterol total, HDL, LDL, dan trigliserida. Silakan tanya secara spesifik tentang salah satu dari ini.'

    response['contact'] = contact_info
    return render_template('index.html', answer=response['answer'], contact=response['contact'])

if __name__ == '__main__':
    app.run(debug=True)
